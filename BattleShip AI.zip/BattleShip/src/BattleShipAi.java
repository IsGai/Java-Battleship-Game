import java.awt.Point;
import java.util.Random;


public class BattleShipAi {
	private int mapSizeX = 3;
	private int mapSizeY = 3;
	private Point shot;
	private Point[] list = new Point[mapSizeX*mapSizeY];
	private Point[] potentialLocation;
	
	public Point generateAiShot() {
		int xPoint = new Random().nextInt(mapSizeX+1);
		int yPoint = new Random().nextInt(mapSizeY+1);
		shot = new Point(xPoint, yPoint);
		
		boolean isInsideArray = false;
		
		for(int i = 0; i < mapSizeX*mapSizeY; i++) {
			if(shot.equals(list[i])) {
				isInsideArray = true;
			} 
		}
		
		for(int i = 0; i < mapSizeX*mapSizeY; i++) {
			if (list[i] == null) {
				
				if(isInsideArray != true) {
					list[i] = shot;
				}
			}
		}
		
		return shot;
	}		
	
	

	
	public void potentialLocation(Point hitPoint) {
		
		Point newShot1 = hitPoint;
		newShot1.translate(1, 0);
		
		Point newShot2 = hitPoint;
		newShot2.translate(-1, 0);
		
		Point newShot3 = hitPoint;
		newShot3.translate(0, 1);
		
		Point newShot4 = hitPoint;
		newShot4.translate(0, -1);
		
		potentialLocation[0] = newShot1;
		potentialLocation[1] = newShot2;
		potentialLocation[2] = newShot3;
		potentialLocation[3] = newShot4;
		
	}
	
	
	

	public static void main(String[] args) {
		Point shoot = new Point();
		shoot = generateAiShot();
		System.out.println(shoot);
		
	}
	
}
