


	import java.awt.*;

	import battleship.source.Ship.Rotated;
	
	public class CarrierShip extends Ship{
		private Point body2Location;
		private Point tailLocation;
		private boolean isTailHit;
		private boolean isBody2Hit;
		
		
		public CarrierShip() {
			setLocation(new Point(0,0), Rotated.UP);
			setHeadHit(false);
			setBodyHit(false);
			setBody2Hit(false);
			setTailHit(false);
			setDead(false);
		}
		public CarrierShip(int x, int y, Rotated rotation) {
			setLocation(new Point(x,y), rotation);
			setHeadHit(false);
			setBodyHit(false);
			setBody2Hit(false);
			setTailHit(false);
			setDead(false);
		}
		public void setLocation(Point headLocation, Rotated rotation) {
			setHeadLocation(headLocation);
			if(rotation==Rotated.UP) {
				setBodyLocation(moveDown(headLocation));
				setTailLocation(moveDown(getBodyLocation()));
			}
			if(rotation==Rotated.DOWN) {
				setBodyLocation(moveUp(headLocation));
				setTailLocation(moveUp(getBodyLocation()));
			}
			if(rotation==Rotated.LEFT) {
				setBodyLocation(moveRight(headLocation));
				setTailLocation(moveRight(getBodyLocation()));
			}
			if(rotation==Rotated.RIGHT) {
				setBodyLocation(moveLeft(headLocation));
				setTailLocation(moveLeft(getBodyLocation()));
			}
		}
		public Point getBody2Location() {
			return body2Location;
		}
		public void setBody2Location(Point Body2Location) {
			this.body2Location = Body2Location;
		}
		public boolean isBody2Hit() {
			return isBody2Hit;
		}
		public void setBody2Hit(boolean isBody2Hit) {
			this.isBody2Hit = isBody2Hit;
		}
		public Point getTailLocation() {
			return tailLocation;
		}
		public void setTailLocation(Point tailLocation) {
			this.tailLocation = tailLocation;
		}
		public boolean isTailHit() {
			return isTailHit;
		}
		public void setTailHit(boolean isTailHit) {
			this.isTailHit = isTailHit;
		}
		/*public String toString() {
			return "BattleShip [getTailLocation()=" + getTailLocation() + ", isTailHit()=" + isTailHit()
					+ ", getHeadLocation()=" + getHeadLocation() + ", getBodyLocation()=" + getBodyLocation()
					+ ", getRotation()=" + getRotation() + ", isHeadHit()=" + isHeadHit() + ", isBodyHit()=" + isBodyHit()
					+ ", isDead()=" + isDead() + ", toString()=" + super.toString() + ", getClass()=" + getClass()
					+ ", hashCode()=" + hashCode() + "]";
		}*/
	}


